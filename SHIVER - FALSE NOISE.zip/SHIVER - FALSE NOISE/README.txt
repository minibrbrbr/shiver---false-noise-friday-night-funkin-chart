DOWNLOAD INSTRUCTIONS

1: copy everything into the assets folder
2: delete the thorns_voices file (make sure you have a backup)

you're good to go

original song by false noise

original game by ninjamuffin99, phantomarcade, kawaiisprite, and evilsk8er